﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using midtermExamExercise.Models;

namespace midtermExamExercise.Models
{

    public class Room
    {
        public string Id { get; set; }
        public int Number { get; set; }
        public int Floor { get; set; }
        public string Type { get; set; }
        public int BedNumber { get; set; }
        public bool Smoking { get; set; }
        public bool Availability { get; set; }
    }

}

         
    


