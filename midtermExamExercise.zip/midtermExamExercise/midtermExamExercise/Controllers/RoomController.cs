﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using midtermExamExercise.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace midtermExamExercise.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]
    public class RoomController : ControllerBase
    {
        public static List<Room> rooms = new List<Room> {
            new Room { Id= "1" , Number= 100, Floor=2, Type="Standard", BedNumber=2, Smoking=false, Availability = true},
            new Room { Id= "2" , Number= 400, Floor=4, Type="Deluxe", BedNumber=3, Smoking=true, Availability = false}
        };

        // GET api/room/GetAll
        [HttpGet]
        [Route("")]
        [Route("GetAll")]
        public IEnumerable<Room> Get()
        {
            return ReturnAllRooms();
        }

        // GET api/room/Get/2
        [HttpGet]
        [Route("Get/{id:int}")]
        public IActionResult Get(string id)
        {
            Room room = ReturnRoomById(id);

            if (room == null)
            {
                return NotFound("Room with that ID does not exist!");
            }
            return Ok(room);
        }

        // POST api/room/Create
        [HttpPost]
        [Route("Create")]
        public IActionResult Post([FromBody] Room room)
        {

            if (rooms.Exists(r => r.Id == room.Id))
            {
                return Conflict("Room with that ID already exist!");
            }
            rooms.Add(room);

            return Created(new Uri($"api/room/Get/{room.Id}", UriKind.Relative), room.Id);

         
        }

        // PUT api/room/Update/2
        [HttpPut]
        [Route("Update/{id:int}")]
        public IActionResult Put(string id, [FromBody] Room updatedRoom)
        {
            Room room = ReturnRoomById(id);
            if (room == null)
            {
                return NotFound("Room with that ID does not exist!");
            }
            room.Id = room.Id;
            room.Number = updatedRoom.Number;
            room.Floor = updatedRoom.Floor;
            room.Type = updatedRoom.Type;
            room.BedNumber = updatedRoom.BedNumber;
            room.Smoking = updatedRoom.Smoking;
            room.Availability = updatedRoom.Availability;
            return Ok($"Room with ID {updatedRoom.Id} is sucessfully updated");
        }

        // DELETE api/room/Delete/2
        [HttpDelete]
        [Route("Delete/{id:int}")]
        public IActionResult Delete(string id)
        {
            Room room = ReturnRoomById(id);
            if (room == null)
            {
                return NotFound("Room with that ID does not exist");
            }
            rooms.Remove(room);
            return Ok($"Room with ID {room.Id} is sucessfully deleted");
        }

        private IEnumerable<Room> ReturnAllRooms()
        {
            return rooms;
        }

        private Room ReturnRoomById(string id)
        {
            Room room = rooms.FirstOrDefault(r => r.Id == id);
            return room;
        }
    }
}


