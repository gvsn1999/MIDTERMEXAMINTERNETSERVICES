﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using midtermExamExercise.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace midtermExamExercise.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class GuestController : ControllerBase
    {
        public static List<Guest> guests = new List<Guest> {
            new Guest {Id= "1" , FirstName="Nina", LastName="Gievska", DOB=new DateTime(1999, 11, 18), Nationality="Macedonian", Country="Macedonia", City="Sveti Nikole", CheckIn=new DateTime(2023, 4, 07), CheckOut=new DateTime(2023, 4, 15), PassportNumber="MK123456" },
            new Guest { Id= "" , FirstName="Miley", LastName="Cyrus", DOB=new DateTime(1992, 11, 23), Nationality="American", Country="USA", City="New York", CheckIn=new DateTime(2023, 4, 10), CheckOut=new DateTime(2023, 4, 20), PassportNumber="USA235670"}
        };

        // GET api/guest/GetAll
        [HttpGet]
        [Route("")]
        [Route("GetAll")]
        public IEnumerable<Guest> Get()
        {
            return ReturnAllGuests();
        }

        // GET api/guest/Get/2
        [HttpGet]
        [Route("Get/{id:int}")]
        public IActionResult Get(string id)
        {
            Guest guest = ReturnGuestById(id);

            if (guest == null)
            {
                return NotFound("Guest with that ID does not exist!");
            }
            return Ok(guest);
        }

        // POST api/guest/Create
        [HttpPost]
        [Route("Create")]
        public IActionResult Post([FromBody] Guest guest)
        {

            if (guests.Exists(g => g.Id == guest.Id))
            {
                return Conflict("Guest with that ID already exist!");
            }
            guests.Add(guest);

            return Created(new Uri($"api/guest/Get/{guest.Id}", UriKind.Relative), guest.Id);


        }

        // PUT api/guest/Update/2
        [HttpPut]
        [Route("Update/{id:int}")]
        public IActionResult Put(string id, [FromBody] Guest updatedGuest)
        {
            Guest guest = ReturnGuestById(id);
            if (guest == null)
            {
                return NotFound("Guest with that ID does not exist!");
            }
            guest.Id = guest.Id;
            guest.FirstName = updatedGuest.FirstName;
            guest.LastName = updatedGuest.LastName;
            guest.DOB = updatedGuest.DOB;
            guest.Nationality = updatedGuest.Nationality;
            guest.Country = updatedGuest.Country;
            guest.City = updatedGuest.City;
            guest.CheckIn = updatedGuest.CheckIn;
            guest.CheckOut = updatedGuest.CheckOut;
            guest.RoomNumber = updatedGuest.RoomNumber;
            return Ok($"Guest with ID {updatedGuest.Id} is sucessfully updated");
        }

        // DELETE api/guest/Delete/2
        [HttpDelete]
        [Route("Delete/{id:int}")]
        public IActionResult Delete(string id)
        {
            Guest guest = ReturnGuestById(id);
            if (guest == null)
            {
                return NotFound("Guest with that ID does not exist");
            }
            guests.Remove(guest);
            return Ok($"Guest with ID {guest.Id} is sucessfully deleted");
        }

        private IEnumerable<Guest> ReturnAllGuests()
        {
            return guests;
        }

        private Guest ReturnGuestById(string id)
        {
            Guest guest = guests.FirstOrDefault(g => g.Id == id);
            return guest;
        }
    }
}
